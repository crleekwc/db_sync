.. currentmodule:: gi.repository

Scale
=====
A :class:`Gtk.Scale` is a slider control used to select a numeric value.